
#include "PizzaStore.h"
#include "ChicagoPizzaStore.h"
#include "NYPizzaStore.h"
#include "Pizza.h"
#include <iostream>
#include <new>

using namespace std;

void main()
{
	PizzaStore *nyStore = new NYPizzaStore();
	PizzaStore *chicagoStore = new ChicagoPizzaStore();

	Pizza *pizza = nyStore->orderPizza("cheese");
	cout << "Ethan Ordered a " + pizza->getname() << endl;
	cout << endl;cout << endl;

	pizza = chicagoStore->orderPizza("veggie");
	cout << "Joel ordered a " + pizza->getname() << endl;
	cout << endl;cout << endl;

	char ch = cin.get();

}