
#include "NYPizzastore.h"
#include "NYPizzaIngredientFactory.h"
#include "Pizza.h"
#include "CheesePizza.h"
#include "VeggiePizza.h"
#include "PepperoniPizza.h"
#include <iostream>
#include <new>

using namespace std;

Pizza* NYPizzaStore::createPizza(std::string type)
{
	Pizza* pizza = NULL;
	PizzaIngredientFactory* ingredientFactory = new NYPizzaIngredientFactory();

	if(type == static_cast<std::string> ("cheese") )
	{
		pizza = new CheesePizza(ingredientFactory);
		pizza->setname("New York Style Cheese Pizza");
	}
	else if(type == static_cast<std::string> ("veggie") )
	{
		pizza = new VeggiePizza(ingredientFactory);
		pizza->setname("New York Style Veggie Pizza");
	}
	else if(type == static_cast<std::string> ("pepperoni") )
	{
		pizza = new PepperoniPizza(ingredientFactory);
		pizza->setname("New York Style Pepperoni Pizza");
	}
	
	return pizza;
}