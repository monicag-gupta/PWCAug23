
#include "Veggies.h"

Veggies::~Veggies()
{

}