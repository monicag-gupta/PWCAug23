
#include "CheesePizza.h"
#include <string>
#include <iostream>

using namespace std;

void CheesePizza::prepare()
{
	cout << "Preparing " + name << endl;
	dough = ingredientFactory->createDough();
	sauce = ingredientFactory->createSauce();
	cheese = ingredientFactory->createCheese();
	clam	= ingredientFactory->createClams();

}