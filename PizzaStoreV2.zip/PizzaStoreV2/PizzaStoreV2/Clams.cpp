
#include "Clams.h"

Clams::~Clams()
{

}