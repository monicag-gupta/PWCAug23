
#include "Cheese.h"

Cheese::~Cheese()
{

}