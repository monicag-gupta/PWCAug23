
#include "Pepperoni.h"
#include <iostream>

class SlicedPepperoni : public Pepperoni
{
  public:
	
	SlicedPepperoni()
	{
		std::cout << "Sliced Pepperoni... \n";
	}

};