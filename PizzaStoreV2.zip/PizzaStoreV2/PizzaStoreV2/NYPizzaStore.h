
#ifndef _ny_pizza_store_h_
#define _ny_pizza_store_h_

#include "PizzaStore.h"

class NYPizzaStore : public PizzaStore
{
	Pizza* createPizza(std::string type);
};

#endif