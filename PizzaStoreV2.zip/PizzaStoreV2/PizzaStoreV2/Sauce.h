#ifndef _sauce_h_
#define _sauce_h_

class Sauce
{
  public:

	  virtual ~Sauce()=0;
	
};

#endif