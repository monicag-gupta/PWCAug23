
#ifndef _cheese_pizza_h_
#define _cheese_pizza_h_

#include "Pizza.h"
#include "PizzaIngredientFactory.h"

class CheesePizza : public Pizza
{
  public:
	CheesePizza(PizzaIngredientFactory* ingredientFactory)
	{
		this->ingredientFactory = ingredientFactory;
	}

	void prepare();

private:
	PizzaIngredientFactory* ingredientFactory;

};

#endif