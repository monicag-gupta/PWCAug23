
#ifndef _dough_h_
#define _dough_h_

class Dough
{
  public:
	
	  virtual ~Dough()=0;

};


#endif