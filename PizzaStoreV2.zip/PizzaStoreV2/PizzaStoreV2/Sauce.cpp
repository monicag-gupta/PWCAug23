
#include "Sauce.h"

Sauce::~Sauce()
{

}