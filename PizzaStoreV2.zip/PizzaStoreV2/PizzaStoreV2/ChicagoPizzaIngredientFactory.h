#ifndef _chicago_pizza_ingredient_factory_h_
#define _chicago_pizza_ingredient_factory_h_

#include "PizzaIngredientFactory.h"

class ChicagoPizzaIngredientFactory : public PizzaIngredientFactory
{
public:

	Dough* createDough();
	Sauce* createSauce();
	Veggies* createVeggies();
	Cheese*	createCheese();
	Pepperoni* createPepperoni();
	Clams* createClams();


};

#endif