//////////////////////////////////////////////////////////////////////////////////////////
// After learning "encapsulate what varies"
// Apply technique "encapsulate the code that create objects". When you have code that 
// create objects or instantiates concrete classes, this is an area of frequent change.
//
// Factory Method : define an interface to create ojbects, but lets subclasses decide 
// which class to instantiate. factory method let a class defer instantiation to subclass.
// So client depend only on interface rather than on concrete classes, this allows program
// to interface, not an implementation.
//
// Dependency Inversion Principle : Depend upon abstraction. Do not depend upon concrete
// classes.
//
//In addition we will also see 'Abstract factory' in action
//
//
//////////////////////////////////////////////////////////////////////////////////////////




#ifndef _pizza_store_h_
#define _pizza_store_h_

#include "Pizza.h"
#include <string>

class PizzaStore
{
  public:

	  virtual Pizza* createPizza(std::string type) = 0;			// factory method

	  Pizza* orderPizza(std::string type);
};


#endif