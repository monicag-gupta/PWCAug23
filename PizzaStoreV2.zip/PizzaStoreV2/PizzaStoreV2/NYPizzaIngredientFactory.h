#ifndef _ny_pizza_ingredient_factory_h_
#define _ny_pizza_ingredient_factory_h_

#include "PizzaIngredientFactory.h"

class NYPizzaIngredientFactory : public PizzaIngredientFactory
{
  public:

	  Dough* createDough();
	  Sauce* createSauce();
	  Veggies* createVeggies();
	  Cheese* createCheese();
	  Pepperoni* createPepperoni();
	  Clams* createClams();


};

#endif