
#include "Veggies.h"
#include <iostream>

class RoyalVeggies : public Veggies
{
  public:
	
	  RoyalVeggies()
	  {
		  std::cout << "Royal Veggies... \n";
	  }

};