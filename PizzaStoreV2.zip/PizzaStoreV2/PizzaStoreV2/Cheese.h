
#ifndef _cheese_h_
#define _cheese_h_

class Cheese
{
  public:

	  virtual ~Cheese() = 0;
};


#endif