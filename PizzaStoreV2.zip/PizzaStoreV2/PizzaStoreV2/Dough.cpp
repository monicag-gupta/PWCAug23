
#include "Dough.h"

Dough::~Dough()
{

}