
#include "Sauce.h"
#include <iostream>

class PlumTomatoSauce : public Sauce
{
public:
	
	PlumTomatoSauce()
	{
		std::cout << "Plum Tomato Sauce... \n";
	}
};