
#ifndef _pepperoni_h_
#define _pepperoni_h_

class Pepperoni
{
  public:
	
	  virtual ~Pepperoni()=0;
};

#endif