
#include "PepperoniPizza.h"
#include <string>
#include <iostream>

using namespace std;

void PepperoniPizza::prepare()
{
	cout << "Preparing " + name << endl;
	dough = ingredientFactory->createDough();
	sauce = ingredientFactory->createSauce();
	cheese = ingredientFactory->createCheese();
	pepperoni = ingredientFactory->createPepperoni();
	clam = ingredientFactory->createClams();

}