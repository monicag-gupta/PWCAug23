
#ifndef _veggie_pizza_h_
#define _veggie_pizza_h_

#include "Pizza.h"
#include "PizzaIngredientFactory.h"

class VeggiePizza : public Pizza
{
public:
	VeggiePizza (PizzaIngredientFactory* ingredientFactory)
	{
		this->ingredientFactory = ingredientFactory;
	}

	void prepare();

private:
	PizzaIngredientFactory* ingredientFactory;

};

#endif