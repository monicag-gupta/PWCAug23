
#ifndef _thin_crust_dough_h_
#define _thin_crust_dough_h_

#include "Dough.h"
#include <iostream>

class ThinCrustDough : public Dough
{
public:
	
	ThinCrustDough()
	{
		std::cout << "Thin Crust Dough... \n";
	}
};
 

#endif