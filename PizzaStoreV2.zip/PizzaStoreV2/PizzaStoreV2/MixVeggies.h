
#include "Veggies.h"
#include <iostream>

class MixVeggies : public Veggies
{
public:
	
	MixVeggies()
	{
		std::cout << "Mix Veggies... \n";
	}

};