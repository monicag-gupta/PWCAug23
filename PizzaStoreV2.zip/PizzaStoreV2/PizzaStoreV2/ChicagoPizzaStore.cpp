
#include "ChicagoPizzaStore.h"
#include "ChicagoPizzaIngredientFactory.h"
#include "Pizza.h"
#include "CheesePizza.h"
#include "VeggiePizza.h"
#include "PepperoniPizza.h"
#include <iostream>
#include <new>

using namespace std;

Pizza* ChicagoPizzaStore::createPizza(std::string type)
{
	Pizza* pizza = NULL;
	PizzaIngredientFactory* ingredientFactory = new ChicagoPizzaIngredientFactory();

	if(type == static_cast<std::string> ("cheese") )
	{
		pizza = new CheesePizza(ingredientFactory);
		pizza->setname("Chicago Style Cheese Pizza");
	}
	else if(type == static_cast<std::string> ("veggie") )
	{
		pizza = new VeggiePizza(ingredientFactory);
		pizza->setname("Chicago Style Veggie Pizza");
	}
	else if(type == static_cast<std::string> ("pepperoni") )
	{
		pizza = new PepperoniPizza(ingredientFactory);
		pizza->setname("Chicago Style Pepperoni Pizza");
	}
	
	return pizza;
}