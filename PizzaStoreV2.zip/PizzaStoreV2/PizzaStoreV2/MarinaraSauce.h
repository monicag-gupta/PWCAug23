
#include "Sauce.h"
#include <iostream>

class MarinaraSauce : public Sauce
{
public:
	
	MarinaraSauce()
	{
		std::cout << "Marinara Sauce... \n";
	}

};