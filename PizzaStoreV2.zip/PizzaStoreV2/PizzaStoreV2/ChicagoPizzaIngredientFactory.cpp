
#include "ChicagoPizzaIngredientFactory.h"
#include "FrozenClams.h"
#include "PlumTomatoSauce.h"
#include "ThickCrustDough.h"
#include "MozzarellaCheese.h"
#include "RoyalVeggies.h"
#include "SlicedPepperoni.h"
#include <new>

using namespace std;

Dough* ChicagoPizzaIngredientFactory::createDough()
{
	return new ThickCrustDough();
}

Sauce* ChicagoPizzaIngredientFactory::createSauce()
{
	return new PlumTomatoSauce();
}

Cheese* ChicagoPizzaIngredientFactory::createCheese()
{
	return new MozzarellaCheese();
}

Veggies* ChicagoPizzaIngredientFactory::createVeggies()
{
	return new RoyalVeggies();
}

Pepperoni* ChicagoPizzaIngredientFactory::createPepperoni()
{
	return new SlicedPepperoni();
}

Clams* ChicagoPizzaIngredientFactory::createClams()
{
	return new FrozenClams();
}

