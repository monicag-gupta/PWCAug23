
#ifndef _clams_h_
#define _clams_h_

class Clams
{
public:
	
	virtual ~Clams()=0;
};

#endif