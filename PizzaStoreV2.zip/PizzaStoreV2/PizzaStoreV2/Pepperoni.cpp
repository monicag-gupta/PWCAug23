
#include "Pepperoni.h"

Pepperoni::~Pepperoni()
{

}