#ifndef _veggies_h_
#define _veggies_h_

class Veggies
{
  public:
	
	  virtual ~Veggies()=0;
};


#endif