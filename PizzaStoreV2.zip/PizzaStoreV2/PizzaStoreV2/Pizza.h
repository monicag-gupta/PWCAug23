
#ifndef _pizza_h_
#define _pizza_h_

#include "Dough.h"
#include "Sauce.h"
#include "Veggies.h"
#include "Cheese.h"
#include "Pepperoni.h"
#include "Clams.h"


#include <string>

class Pizza
{
  public:

	  virtual void prepare() = 0;
	   
	  virtual void bake();

	  virtual void cut();

	  virtual void box();

	  void setname( std::string name)
	  {
		  this->name = name;
	  }

	  std::string getname() 
	  {
		  return name;
	  }

  public:

	  std::string name;
	  Dough* dough;
	  Sauce* sauce;
	  Veggies* veggies;
	  Cheese* cheese;
	  Pepperoni* pepperoni;
	  Clams* clam;
};

#endif