
#ifndef _chicago_pizza_store_h_
#define _chicago_pizza_store_h_

#include "PizzaStore.h"

class ChicagoPizzaStore : public PizzaStore
{
	Pizza* createPizza(std::string type);
};

#endif