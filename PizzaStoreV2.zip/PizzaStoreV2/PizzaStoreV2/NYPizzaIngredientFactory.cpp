
#include "NYPizzaIngredientFactory.h"
#include "ThinCrustDough.h"
#include "MarinaraSauce.h"
#include "ReggianoCheese.h"
#include "MixVeggies.h"
#include "SlicedPepperoni.h"
#include "FreshClams.h"
#include <new>

using namespace std;

Dough* NYPizzaIngredientFactory::createDough()
{
	return new ThinCrustDough();
}

Sauce* NYPizzaIngredientFactory::createSauce()
{
	return new MarinaraSauce();
}

Cheese* NYPizzaIngredientFactory::createCheese()
{
	return new ReggianoCheese();
}

Veggies* NYPizzaIngredientFactory::createVeggies()
{
	return new MixVeggies();
}

Pepperoni* NYPizzaIngredientFactory::createPepperoni()
{
	return new SlicedPepperoni();
}

Clams* NYPizzaIngredientFactory::createClams()
{
	return new FreshClams();
}