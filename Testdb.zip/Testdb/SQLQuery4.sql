use BikeStores;

SELECT * FROM
    production.products
WHERE
    category_id = 1
AND list_price > 400;



SELECT
    product_name,
    list_price
FROM
    production.products
WHERE
    list_price < 100
OR list_price > 10000;




SELECT  product_name,  list_price
FROM  production.products
WHERE  
list_price IN (89.99, 109.99, 159.99);

SELECT  product_name, list_price
FROM   production.products
WHERE
    list_price NOT IN (89.99, 109.99, 159.99);




SELECT customer_id, first_name, last_name,  phone
FROM  sales.customers
WHERE  phone IS NULL;

SELECT customer_id, first_name, last_name,  phone
FROM  sales.customers
WHERE  phone IS NOT NULL;



SELECT TOP 10
    product_name, list_price
FROM   production.products;


SELECT TOP 2 Percent
    product_name, list_price
FROM   production.products;

SELECT 
    product_name, list_price
FROM   production.products;



SELECT TOP 5
--WITH TIES
    product_name, list_price
FROM production.products 
order by list_price;



SELECT TOP (5) percent
--WITH TIES
    product_name,list_price
FROM production.products 
order by list_price;

SELECT TOP (3) WITH TIES
    product_name, list_price
FROM production.products 
order by product_name, list_price;




Select * from sales.customers where first_name like 'a%';
Select * from sales.customers where first_name like '_a%';

Select * from sales.customers where first_name like '____';

Select * from sales.customers where first_name like '%a_';
Select * from sales.customers where first_name like '%a';



SELECT
    product_id,
    product_name,
    list_price
FROM
    production.products
WHERE
    list_price BETWEEN 149.99 AND 199.99
ORDER BY
    list_price;



	SELECT
    product_id,
    product_name,
    list_price
FROM
    production.products
WHERE
    list_price NOT BETWEEN 149.99 AND 199.99
ORDER BY
    list_price;


SELECT * FROM SALES.CUSTOMERS 
   ORDER BY FIRST_NAME, last_name;


SELECT * FROM SALES.CUSTOMERS 
   ORDER BY FIRST_NAME asc, last_name desc;

SELECT * FROM SALES.CUSTOMERS 
   ORDER BY FIRST_NAME DESC;
select * from sales.orders;
SELECT * FROM SALES.CUSTOMERS;
select * from sales.staffs;


   select * from production.products;

   select Category_id, sum(list_price) from  production.products group by Category_id;

SELECT
    product_name, list_price, category_id
FROM production.products p1
WHERE
    list_price IN (
        SELECT MAX (p2.list_price)
        FROM production.products p2
        WHERE
            p2.category_id = p1.category_id
        GROUP BY p2.category_id
    )
ORDER BY
    category_id, product_name;



SELECT
    MAX(list_price) max_list_price
FROM
    production.products;

SELECT
    MIN(list_price) min_list_price
FROM
    production.products;

SELECT
    *
FROM
    production.products;



SELECT testdb.dbo.udfNetSale(10,list_price,0.1) as net_sale from production.products;







