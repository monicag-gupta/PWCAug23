﻿using System;

namespace PointerUnsafePrj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x = 10;
            unsafe
            {
                int* p = &x;
                int a = (int)p;
                Console.WriteLine((*p) + " has address as : " + a);
            }

        }
    }
}
